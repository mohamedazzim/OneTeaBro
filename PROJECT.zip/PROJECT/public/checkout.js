let items = [];
let topTop = [];
let topTotElm = document.getElementById("whole-bill-total");

// Existing code...

function generateReport() {
    fetch('/generate-report', {
        method: 'GET',
    })
    .then(response => response.blob())
    .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        const today = new Date();
        const date = today.getDate().toString().padStart(2, '0');
        const month = (today.getMonth() + 1).toString().padStart(2, '0');
        const year = today.getFullYear();
        a.download = `report-${date}-${month}-${year}.txt`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
    })
    .catch(error => console.error('Error:', error));
}

// Existing functions (increment, decrement, checkoutfn)...


function increment(e) {
    let n = document.getElementsByClassName(e);  
    items.push(e);
    console.log("m", n, "e", e);
    console.log(e + "-price");

    let itmPrice = parseInt(document.getElementById(e + "-price").textContent);
    let collectivePrice = 0;
    for(let elm of n) {
        let NN = parseInt(elm.textContent);
        console.log(NN);

        NN += 1;
        elm.textContent = NN;
        console.log(NN, itmPrice);
        topTop.push(itmPrice);
        break;
    }

    topTotElm.textContent = topTop.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
}

function remove(array, value) {
    const indexToRemove = array.indexOf(value);
    if (indexToRemove !== -1) {
        array.splice(indexToRemove, 1);
    }
}

function decrement(e) {
    let n = document.getElementsByClassName(e);    
    let itmPrice = parseInt(document.getElementById(e + "-price").textContent);
    for(let elm of n) {
        let NN = parseInt(elm.textContent);
        if(NN <= 0) {
            return;
        }
        NN -= 1;
        elm.textContent = NN;
    }
    remove(topTop, itmPrice);
    topTotElm.textContent = topTop.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
}

function removeDuplicates(arr) {
    return arr.filter((item, index) => arr.indexOf(item) === index);
}

function checkoutfn() {    
    console.log(items);
    let selectedItems = removeDuplicates(items);
    console.log('Selected Items:', selectedItems); // Log selected items

    let payloads = selectedItems.map(sItm => {
        let itm = document.getElementById(sItm);
        console.log('Item Element:', itm); // Log item element
        return {
            name: sItm,
            quantity: parseInt(itm.textContent), // Ensure quantity is a number
            price: parseFloat(document.getElementById(sItm + "-price").textContent) // Ensure price is a number
        };
    });

    console.log('Payloads:', payloads); // Log payloads

    let billData = {
        billNo: Date.now(), // Generate a unique bill number
        date: new Date().toLocaleDateString(),
        items: payloads,
        total: topTop.reduce((acc, curr) => acc + curr, 0).toFixed(2) // Ensure total is a number
    };

    console.log('Bill Data:', billData); // Log bill data

    fetch('/generate-bill', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(billData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.blob().then(blob => ({ blob, response })); // Return both blob and response
    })
    .then(({ blob, response }) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        const filename = response.headers.get('Content-Disposition').split('filename=')[1].replace(/"/g, ''); // Extract filename from headers
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
    })
    .catch(error => console.error('Error:', error));
}
