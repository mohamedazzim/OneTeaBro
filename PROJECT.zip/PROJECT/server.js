const express = require('express');
const path = require('path');
const session = require('express-session');
const mongoose = require('mongoose');
const Item = require('./models/item');
const Bill = require('./models/bill');
const MongoStore = require('connect-mongo');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3060;
require('dotenv').config();

// Ensure the 'bills' directory exists
const billsDirectory = path.join(__dirname, 'bills');
if (!fs.existsSync(billsDirectory)) {
    fs.mkdirSync(billsDirectory);
}

// Ensure the 'reports' directory exists
const reportsDirectory = path.join(__dirname, 'reports');
if (!fs.existsSync(reportsDirectory)) {
    fs.mkdirSync(reportsDirectory);
}

// Set EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Configure session middleware
app.use(session({
    secret: process.env.SECRET,
    resave: false,
    store: MongoStore.create({
      mongoUrl: process.env.DATABASE_URL,
      collectionName: 'sessions',
      ttl: 1 * 60 
  }),
    saveUninitialized: true,
    cookie: { secure: false }
}));

// Home route
app.get('/', async (req, res) => {
  let items = await Item.find({});
  console.log(items);
  res.render('index', { items });
});

// Generate bill and download as file route
app.post('/generate-bill', async (req, res) => {
    try {
        const billData = req.body;
        console.log('Bill Data Received:', billData); // Log received data

        let bucket = [];
        let TOTAL = 0;
        for (const bi of billData.items) {
            let itm = {};
            itm.quantity = Number(bi.quantity);
            let I = await Item.findOne({ id: bi.name.split("-")[0] });
            if (!I) throw new Error(`Item with id ${bi.name} not found`); // Check if item exists
            itm.price = Number(I.price);
            itm.name = I.title;
            itm.total = itm.price * itm.quantity;
            TOTAL += itm.total;
            bucket.push(itm);
        }

        let previousBillNo = await getPreviousBillNO();
        let newBill = new Bill({ billNo: previousBillNo + 1, items: bucket, total: TOTAL });
        await newBill.save();
        console.log('New Bill Saved:', newBill); // Log saved bill

        // Generate bill content
        let billHeader = `Bill No: ${previousBillNo + 1}\nDate: ${new Date().toLocaleString().split(",")[0]}\n\nItem${' '.repeat(25)}Qty${' '.repeat(15)}Price\n`;
        let billContent = billHeader;
        bucket.forEach(item => {
            billContent += `${item.name.padEnd(30)}${item.quantity.toString().padEnd(20)}${item.price.toFixed(2)}\n`;
        });
        billContent += `\nTotal: ${TOTAL.toFixed(2)}`;

        // Format the filename
        const date = new Date();
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        const filename = `bill_${newBill.billNo}_${day}-${month}-${year}.txt`;
        const filePath = path.join(__dirname, 'bills', filename);
        console.log('File Path:', filePath); // Log file path

        fs.writeFile(filePath, billContent, (err) => {
            if (err) {
                console.error('Failed to create bill:', err);
                return res.status(500).json({ error: 'Failed to create bill' });
            }

            console.log('Bill created successfully:', filePath);

            // Set Content-Disposition header to specify the filename
            res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

            // Send file as download
            res.download(filePath, filename, (err) => {
                if (err) {
                    console.error('Failed to download bill:', err);
                    return res.status(500).json({ error: 'Failed to download bill' });
                }

                // Clean up the file after sending
                fs.unlink(filePath, (unlinkErr) => {
                    if (unlinkErr) {
                        console.error('Failed to delete bill file:', unlinkErr);
                    } else {
                        console.log('Bill file deleted successfully:', filePath);
                    }
                });
            });
        });
    } catch (err) {
        console.error('Error during bill generation:', err);
        res.status(500).json({ error: 'Error during bill generation', details: err.message });
    }
});


// Generate daily report and save as file route
app.get('/generate-report', async (req, res) => {
    try {
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date();
        endOfDay.setHours(24, 0, 0, 0);

        const bills = await Bill.find({
            created_at: {
                $gte: startOfDay,
                $lt: endOfDay
            }
        });

        let itemTotals = {};
        let totalTurnover = 0;
        for (const bill of bills) {
            for (const item of bill.items) {
                if (!itemTotals[item.name]) {
                    itemTotals[item.name] = { quantity: 0, price: item.price };
                }
                itemTotals[item.name].quantity += Number(item.quantity);
                totalTurnover += item.price * item.quantity;
            }
        }

        const reportDate = new Date().toISOString().split('T')[0];
        const reportHeader = `ITEM${' '.repeat(25)}Total Quantity${' '.repeat(15)}Total Price\n`;
        const reportContent = Object.keys(itemTotals)
            .map(itemName => {
                const { quantity, price } = itemTotals[itemName];
                const totalPrice = quantity * price;
                return `${itemName.padEnd(30)}${quantity.toString().padEnd(30)}${totalPrice}`;
            })
            .join('\n');
        const totalTurnoverContent = `\n\nTotal Turnover: ${totalTurnover}`;

        const finalReport = reportHeader + reportContent + totalTurnoverContent;

        const filePath = path.join(reportsDirectory, `report-${reportDate}.txt`);
        fs.writeFile(filePath, finalReport, (err) => {
            if (err) {
                console.error('Failed to create report:', err);
                return res.status(500).json({ error: 'Failed to create report' });
            }

            // Send file as download
            res.download(filePath, `report-${reportDate}.txt`, (err) => {
                if (err) {
                    console.error('Failed to download report:', err);
                    return res.status(500).json({ error: 'Failed to download report' });
                }

                // Clean up the file after sending
                fs.unlink(filePath, () => {});
            });
        });
    } catch (err) {
        console.error('Error during report generation:', err);
        res.status(500).json({ error: 'Error during report generation' });
    }
});

async function getPreviousBillNO() {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date();
  endOfDay.setHours(24, 0, 0, 0);
  try {
    let allTicket = await Bill.find({
        created_at: {
            $gte: startOfDay,
            $lt: endOfDay
        }
    });
    console.log(allTicket, allTicket.length);
    return allTicket.length;
  } catch (err) {
    console.log(err);
  }
}

// Bill route
app.get('/bill', async (req, res) => {
    if (req.session.items) {
        console.log(req.session.items);
        console.log(req.session);

        // Compute
        let billItems = req.session.items;
        let bucket = [];
        let TOTAL = 0;
        for (const bi of billItems) {
            let itm = {};
            itm.quantity = bi.quantity;
            let I = await Item.findOne({ id: bi.item.split("-")[0] });
            itm.price = I.price;
            itm.name = I.title;
            itm.total = I.price * bi.quantity;
            TOTAL += (I.price * bi.quantity);
            bucket.push(itm);
        }

        console.log("dfsdfsdf", bucket, TOTAL);
        let previousBillNo = await getPreviousBillNO();

        let newBill = new Bill({ billNo: previousBillNo + 1, items: bucket, total: TOTAL });
        await newBill.save();
        console.log(newBill);

        res.render("about", { items: bucket, total: TOTAL, date: new Date().toLocaleString().split(",")[0], billNO: previousBillNo + 1 });
    } else {
        res.send('Please log in first');
    }
});

// Bill close route
app.get("/bill/close", (req, res) => {
  req.session.destroy(err => {
    if (err) {
        return res.redirect('/bill');
    }
    res.send('Logged out successfully');
  });
});

// Admin routes
app.get("/admin", async (req, res) => {
    try {
        const items = await Item.find();
        res.render('admin', { items });
    } catch (err) {
        res.status(500).send(err);
    }
});

app.post("/admin/add", async (req, res) => {
    const { id, title, price, image } = req.body;
    console.log(req.body);

    const newItem = new Item({ id, title, price, image });
    try {
        await newItem.save();
        console.log(newItem);
        res.redirect('/admin');
    } catch (err) {
        res.status(500).send(err);
    }
});

app.post("/admin/update", async (req, res) => {
    const { id, title, price, image } = req.body;
    console.log(req.body);

    try {
        const item = await Item.findOne({ id });
        item.title = title;
        item.price = price;
        item.image = image;
        await item.save();
        console.log(item);
        res.redirect('/admin');
    } catch (err) {
        res.status(500).send(err);
    }
});

app.post("/admin/delete", async (req, res) => {
    const { id } = req.body;
    try {
        await Item.deleteOne({ id });
        console.log(`Deleted item with id ${id}`);
        res.redirect('/admin');
    } catch (err) {
        res.status(500).send(err);
    }
});

// Connect to MongoDB and start the server
mongoose.connect(process.env.DATABASE_URL)
.then(() => {
    console.log('MongoDB connected...');
    app.listen(PORT, () => {
        console.log(`Server is running on http://localhost:${PORT}`);
    });
})
.catch(err => console.log(err));
